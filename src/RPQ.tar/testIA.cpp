
#include <iostream>
#include "init_array.hpp"
#include <bits/stdc++.h>

using namespace std;

int main() {
    initializable_array<uint64_t> A(20, 0);
    uint64_t i;
    
    for (i = 0; i < A.size(); i++)
        cout << "A["<<i<<"] = " << A[i] << endl;

    A[1] = 524;
   
    A[19] = 123;

    A[0] = 234;

    cout << "*************************" << endl;
    for (i = 0; i < A.size(); i++)
        cout << "A["<<i<<"] = " << A[i] << endl;


    cout << "*************************" << endl;
    A[1]++;
    A[2]++;
    A[3]--;
    A[4]+= 8;
    A[5] += A[2] + A[4];
    for (i = 0; i < A.size(); i++)
        cout << "A["<<i<<"] = " << A[i] << endl;



    return 0;
}
