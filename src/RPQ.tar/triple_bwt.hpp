/*
 * triple_bwt_rpq.hpp
 * Copyright (C) 2020 Author name removed for double blind evaluation
 * 
 * This is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This software is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef TRIPLE_L
#define TRIPLE_L


#include <cstdint>
#include "bwt.hpp"
#include "bwt_interval.hpp"
#include "nfa/src/RpqAutomata.cpp"
//#include "init_array.hpp"
#include <sdsl/init_array.hpp>
#include <chrono>

#include <stdio.h>
#include <stdlib.h>

using namespace std::chrono;


typedef uint16_t word_t;   // Improve this


    uint32_t* dat;

    // Utility function for suffix array construction
    int compare (const void *p1, const void *p2)
    {
        uint64_t r1 = *((uint64_t*)p1);
        uint64_t r2 = *((uint64_t*)p2);
        if (r1 == r2) return 0;
        while (dat[r1] == dat[r2]) { r1++; r2++; }
        return dat[r1]-dat[r2];
    }


#define TIME_OUT 60

class ring_rpq 
 {
    bwt L_S;
    bwt L_P;
    bwt L_O;

    uint64_t real_max_P;

    uint64_t max_S;
    uint64_t max_P;
    uint64_t max_O;
    uint64_t nTriples;  // number of triples

    public:
        ring_rpq() {;}

        // Assumes the triples have been stored in a vector<spo_triple>
        ring_rpq(vector<spo_triple> & D)
        {
            uint64_t i, pos_c;
            vector<spo_triple>::iterator it, triple_begin, triple_end;
            uint64_t n;

            // for every triple, adds its reverse (using a predicate 
	    // shifted by max_P, so 1 becomes max_P+1 in the reverse, 
            // and so on)
		
            uint64_t d = D.size();
            spo_triple triple_aux;

            max_S = get<0>(D[0]);
            max_P = get<1>(D[0]);
            max_O = get<2>(D[0]);

            for (i = 1; i < D.size(); i++) {
                if (max_S < get<0>(D[i])) max_S = get<0>(D[i]);
                if (max_P < get<1>(D[i])) max_P = get<1>(D[i]);
                if (max_O < get<2>(D[i])) max_O = get<2>(D[i]);
            }
            //sigma_S = max_S;
            //sigma_P = max_P;
            //sigma_O = max_O;  // revisar que esto se cumpla. De todas formas, creo que no uso nunca esto, ver. 

            real_max_P = max_P;


            //real_max_P = get<1>(D[i]);

	    for (uint64_t i = 0; i < d; i++) {    
	        triple_aux = D[i]; 
                D.push_back(spo_triple(get<2>(D[i]), get<1>(D[i]), get<0>(D[i])));
                get<0>(D[i]) = get<0>(triple_aux);
		get<1>(D[i]) = get<1>(D[i]) + real_max_P;
		get<2>(D[i]) = get<2>(triple_aux);
                //D[i] = spo_triple(get<2>(D[i]), get<1>(D[i]) + max_P, get<0>(D[i]));
	    }
            cout << "Finalmente son " << D.size() << " triples" << endl;
            D.shrink_to_fit();
	
            max_S = get<0>(D[0]);
            max_P = get<1>(D[0]);
            max_O = get<2>(D[0]);

            for (i = 1; i < D.size(); i++) {
                if (max_S < get<0>(D[i])) max_S = get<0>(D[i]);
                if (max_P < get<1>(D[i])) max_P = get<1>(D[i]);
                if (max_O < get<2>(D[i])) max_O = get<2>(D[i]);
            }

            {
                bit_vector bv_s(max_S+1, 0);
                for (i = 0; i < D.size(); i++) {
	            bv_s[get<0>(D[i])] = 1;
	        }

                bit_vector bv_o(max_O+1, 0);
	        for (i = 0; i < D.size(); i++) {
                    bv_o[get<2>(D[i])] = 1;
                }

                uint64_t _c = 0;
                for (i = 1; i < max_S+1; i++) {
	            if (!bv_s[i]) {
		        D.push_back(spo_triple(i, max_P+1, max_O+1));
                        //cout << i << " is not a subject" << endl; //"added triple (" << i << ", " << max_P+1 << ", " << max_O+1 << ")" << endl;  
                        _c++;
                    }
	        }
                cout << _c << " nodes are no subjects" << endl;
            
                _c = 0;
                for (i = 1; i < max_O+1; i++) {
                    if (!bv_o[i]) {
                        D.push_back(spo_triple(max_O+1, max_P+1, i));
		        _c++;//cout << i << " is not an object" << endl; //"added triple (" << max_O+1 << ", " << max_P+1 << ", " << i << ")" << endl;
		    }
                }

                cout << _c << " nodes are no objects" << endl;
            }

            max_S++; max_O++; max_P++;
            //D.push_back(spo_triple(max_O+1, max_P+1, max_O+1));

            triple_begin = D.begin();
            triple_end = D.end();
            
            cout << "Triples set = " << D.size()*sizeof(spo_triple) << " bytes" << endl; fflush(stdout);


            n = nTriples = triple_end - triple_begin;
/*            int_vector<32> bwt_aux(3*n);
            int_vector<32> bwt_s(n+1);
            int_vector<32> bwt_p(n+1);
*/

            cout << "  > Determining number of elements per symbol..."; fflush(stdout);
            uint64_t alphabet_SO = (max_S < max_O)? max_O: max_S;

            std::vector<uint32_t> M_O(alphabet_SO+1), M_P(max_P+1);  
            cout << "M_O = " << M_O.size()*sizeof(uint32_t) << " bytes" << endl; fflush(stdout);
            cout << "M_P = " << M_P.size()*sizeof(uint32_t) << " bytes" << endl; fflush(stdout);


            for (i = 0; i <= alphabet_SO; i++) {
		M_O[i] = 0;
	    } 

	    for (i = 0; i <= max_P; i++)
	        M_P[i] = 0;

            for (i = 0; i < D.size(); i++) {
	        M_O[std::get<2>(D[i])]++;
		M_P[std::get<1>(D[i])]++;
	    }

            M_O.shrink_to_fit();
            M_P.shrink_to_fit();

            cout << "Done\n  > Sorting out triples..."; fflush(stdout);
            // Sorts the triples lexycographically 
            sort(triple_begin, triple_end);
            cout << "Done" << endl; fflush(stdout);
            
                dat = new uint32_t[3*n+2];
                uint32_t *t = dat;
                cout << "t = " << (3*n+2)*sizeof(uint32_t) << " bytes" << endl;
            
                cout << "  > Generating int vector of the triples"; fflush(stdout);
                for (i=0, it=triple_begin; it != triple_end; it++, i++) {
                    t[3*i]   = std::get<0>(*it);
                    t[3*i+1] = std::get<1>(*it) + /*max_S;*/ n;   
                    t[3*i+2] = std::get<2>(*it) + /*max_P + max_S; //*/ 2*n; 
                }
                t[3*n] = 3*n; //max_S + max_P + max_O + 1;
                t[3*n+1] = 0;
                D.clear();
                D.shrink_to_fit();
                cout << "...done" << endl;
                cout << "  > Building the suffix array"; fflush(stdout);
                uint64_t *sa = new uint64_t[3*n+1];
                cout << "sa = " << (3*n+2)*sizeof(uint64_t) << " bytes" << endl; fflush(stdout);
                cout << "3*n+1 = " << 3*n+1 << " bytes" << endl;

                for (i=0; i < n; i++) sa[i] = 3*i;
                for (i=n; i < 2*n; i++) sa[i] = 3*(i-n)+1;
                for (i=2*n; i < 3*n; i++) sa[i] = 3*(i-2*n)+2;
                sa[3*n] = 3*n;
                qsort(sa+n,n,sizeof(uint64_t),compare);
                qsort(sa+2*n,n,sizeof(uint64_t),compare);
            
                cout << "...done" << endl;
                cout << "  > Building the global L"; fflush(stdout);

                //int_vector<32> bwt_aux(3*n);
	        int_vector<> bwt_s(n+1);
		//int_vector<> bwt_p(n+1);
                cout << "bwt_s = " << size_in_bytes(bwt_s) << " bytes" << endl;

                uint64_t j;
                // L_s
                bwt_s[0] = 0;
                for (j=1, i=n; i<2*n; i++) {
		    if (sa[i] >= 3*n) continue;
		    if (sa[i]==0) {
                        cout << "Emporaquí adentra S" << endl;
		        bwt_s[j] = t[3*n-1]; // OJO, no estoy seguro si es t[n-1], no seria t[3*n-1]?
                    }
		    else
		        bwt_s[j] = t[sa[i]-1];
                    j++;
		} 
                util::bit_compress(bwt_s); 
                cout << "bwt_s compressed = " << size_in_bytes(bwt_s) << " bytes" << endl;		 

                int_vector<> bwt_p(n+1);
                cout << "bwt_p = " << size_in_bytes(bwt_p) << " bytes" << endl; fflush(stdout);
		// L_p
                bwt_p[0] = 0;
                for (j=1, i=2*n; i<3*n; i++) {
                    //if (j == 307378798) 
                        //cout << "OJO sa[i] = " << sa[i] << endl;
                    if (sa[i] >= 3*n) continue;
                    if (sa[i]==0) {
                        cout << "Emporaquí adentra P" << endl;
                        bwt_p[j] = t[3*n-1]-n;//max_S;//n; // OJO, no estoy seguro si es t[n-1], no seria t[3*n-1]?
                    }
                    else 
                        bwt_p[j] = t[sa[i]-1]-n;//max_S;//n;
                    //if (j == 307378798)
                        //cout << "bwt[" << j << "] = " << bwt_p[j] << endl;
                    j++;
                }
                util::bit_compress(bwt_p);
                cout << "bwt_p compressed = " << size_in_bytes(bwt_p) << " bytes" << endl; fflush(stdout);

                ///////////////////////
                /*for (j=i=0; i < 3*n; i++) {
                    if (sa[i] >= 3*n) continue;
                    if (sa[i] == 0)
                        bwt_aux[j] = t[3*n-1];  // OJO, no estoy seguro si es t[n-1], no seria t[3*n-1]?
                    else bwt_aux[j] = t[sa[i]-1];
                    j++;
                }*/
                ///////////////////////
                delete [] sa;
                delete [] t;
                cout << "...done" << endl;
            

            // Then S
                uint64_t c;            
                ///////////////////////
                /*cout << "  > Building L_S"; fflush(stdout);
                int_vector<> S(n+1);
                j = 1;
                //vector<uint32_t> C_S;
                S[0] = 0;
                i = n;  
                while (i<2*n) {
                    S[j] = bwt_aux[i++];
		    if (S[j] != bwt_s[j]) {
		        cout << " Distintos en L_s " << j << " " << S[j] << " " << bwt_s[j] << endl;
			exit(1);
		    }
		    j++;
                }
                util::bit_compress(S);*/
                ///////////////////////  
                cout << "  > Building C_S"; fflush(stdout);
                vector<uint64_t> C_S;
                uint64_t cur_pos = 1;
                C_S.push_back(0);  // Dummy value
                C_S.push_back(cur_pos);
                for (c = 2; c <= max_P; c++) {
                    cur_pos += M_P[c-1];
                    C_S.push_back(cur_pos);
                }
                C_S.push_back(n+1);
                C_S.shrink_to_fit();
                cout << "C_S = " << C_S.size()*sizeof(uint64_t) << " bytes" << endl; fflush(stdout);
                M_P.clear();
                M_P.shrink_to_fit();
                L_S = bwt(bwt_s/*S*/, C_S);
		C_S.clear();
		C_S.shrink_to_fit();
                //cout << "...done" << endl;
            

            // Then P
                ///////////////////////
                /*cout << "  > Building L_P"; fflush(stdout);
                int_vector<> P(n+1);
                //uint64_t 
                j = 1;
                //vector<uint32_t> C_P;
                P[0] = 0;
                while (i<3*n) {
                    P[j] = bwt_aux[i++] - n;
		    if (P[j] != bwt_p[j]) {
		        cout << "Distintos en L_p " << j << endl;
			exit(1);
		    }
		    j++;
                }
                util::bit_compress(P);*/
                ///////////////////////
                cout << "  > Building C_P"; fflush(stdout);
                vector<uint64_t> C_P;
                cur_pos = 1;
                C_P.push_back(0);  // Dummy value
                C_P.push_back(cur_pos);
                for (c = 2; c <= alphabet_SO; c++) {
                    cur_pos += M_O[c-1];
                    C_P.push_back(cur_pos); 
                }
                C_P.push_back(n+1);
                C_P.shrink_to_fit();
                cout << "C_P = " << C_P.size()*sizeof(uint64_t) << " bytes" << endl; fflush(stdout);

		M_O.clear();
                M_O.shrink_to_fit();
                L_P = bwt(bwt_p/*P*/, C_P);
		C_P.clear();
		C_P.shrink_to_fit();
                //cout << "...done" << endl;			
            

            cout << "-- Index constructed successfully" << endl; fflush(stdout);
        };

        uint64_t size()
        {
            //cout << "L_O: " << (float)L_O.size()*8/nTriples << endl; 
            //cout << "L_S: " << (float)L_S.size()/nTriples << " bytes per Triple" << endl; 
            //cout << "L_P: " << (float)L_P.size()/nTriples << " bytes per triple" << endl; 
            
            //cout << "L_S.size() = " << L_S.size() << " bytes" << endl;
            //cout << "L_P.size() = " << L_P.size() << " bytes" << endl;
            //cout << "nTriples = " << nTriples << endl;
            return L_S.size() + L_P.size();
        }

        uint64_t n_labels()
	{
	    return max_P;  // should be the same as max_S
	}

	void save(string filename)
	{
	    L_S.save(filename+".bwts");
	    L_P.save(filename+".bwtp");

	    std::ofstream ofs(filename+".nTriples");
	    ofs << nTriples << endl;
	    ofs << real_max_P << endl;
            ofs << max_S << endl;
	    ofs << max_P << endl;
	    ofs << max_O << endl;
	};

        void load(string filename)
        {
            //cout << "Loading L_S" << endl; fflush(stdout);
            L_S.load(filename+".bwts");
            //cout << "Loading L_P" << endl; fflush(stdout);
            L_P.load(filename+".bwtp");
            //cout << "Loading done" << endl; fflush(stdout);
            std::ifstream ifs(filename+".nTriples");
            ifs >> nTriples;
            ifs >> real_max_P;
            ifs >> max_S;
            ifs >> max_P;
            ifs >> max_O;
        };

private:
        void step_1(RpqAutomata& A, std::vector<word_t>& B_array,
	            word_t current_D, bwt_interval& I_p, 
		    vector<std::pair<bwt_interval, word_t>>& input_for_step_2)
        // I_p is an interval in L_P
	{
	    // first, search for all elements in I_p that lead to an active state
	    std::vector<uint64_t> 
            values_in_I_p = L_P.all_active_p_values_in_range<word_t>(I_p.left(), I_p.right(), B_array, current_D);

	    // A continuación, por cada valor en el vector anterior, debo aplicar un backward step para obtener un intervalo
	    // en L_S. Esos se agregan al vector "input_for_step_2". 
            std::pair<uint64_t, uint64_t> interval_aux;
	    
	    for (uint64_t i = 0; i < values_in_I_p.size(); i++) {
                interval_aux = L_P.backward_step(I_p.left(), I_p.right(), values_in_I_p[i]); 
		uint64_t c = L_S.get_C(values_in_I_p[i]);
	        input_for_step_2.push_back(
		                           std::pair<bwt_interval, word_t>(bwt_interval(c+interval_aux.first, c+interval_aux.second),
					   (word_t) A.next(current_D, values_in_I_p[i], BWD)) // actualiza el estado para ese intervalo 
					  );

	    }	
	    
	}


        void step_2(RpqAutomata& A, initializable_array<word_t>& D_array, word_t current_D, bwt_interval& I_s,  
	            std::vector<std::pair<bwt_interval, word_t>>& input_for_step_1,
		    uint64_t starting_o,
                    std::vector<std::pair<uint64_t,uint64_t>>& output_subjects,
		    bool const_to_var = true
                   )
        {

            std::vector<std::pair<uint64_t, word_t>> 
            values_in_I_s = L_S.all_active_s_values_in_range<word_t>(I_s.left(), I_s.right(), D_array, current_D);
            
	    // Por cada elemento s reportado en el paso anterior, tengo que hacer un backward step para irme a un intervalo en L_o.
	    // Ver como hago esto, si conviene hacerlo aqui o en el paso 3
	    std::pair<uint64_t, uint64_t> interval_aux;
            for (uint64_t i = 0; i < values_in_I_s.size(); i++) {
	        interval_aux = L_S.backward_step(I_s.left(), I_s.right(), values_in_I_s[i].first);
		uint64_t c = L_P.get_C(values_in_I_s[i].first);  
		
		input_for_step_1.push_back(
		                           std::pair<bwt_interval, word_t>(bwt_interval(c, L_P.get_C(values_in_I_s[i].first+1)-1),
					   values_in_I_s[i].second)
		                          );

		if (A.atFinal(values_in_I_s[i].second, BWD)) {
		    if (const_to_var)
		        output_subjects.push_back(std::pair<uint64_t,uint64_t>(starting_o,values_in_I_s[i].first));
                    else
		        output_subjects.push_back(std::pair<uint64_t,uint64_t>(values_in_I_s[i].first,starting_o));
		}
	    }            
	}


       bool step_2_check(RpqAutomata& A, initializable_array<word_t>& D_array, word_t current_D, bwt_interval& I_s,
                         std::vector<std::pair<bwt_interval, word_t>>& input_for_step_1
                        )
        {
            std::vector<std::pair<uint64_t, word_t>>
            values_in_I_s = L_S.all_active_s_values_in_range<word_t>(I_s.left(), I_s.right(), D_array, current_D);

            // Por cada elemento s reportado en el paso anterior, tengo que hacer un backward step para irme a un intervalo en L_o.
            // Ver como hago esto, si conviene hacerlo aqui o en el paso 3
            std::pair<uint64_t, uint64_t> interval_aux;
            for (uint64_t i = 0; i < values_in_I_s.size(); i++) {
                interval_aux = L_S.backward_step(I_s.left(), I_s.right(), values_in_I_s[i].first);
                uint64_t c = L_P.get_C(values_in_I_s[i].first);

                if (A.atFinal(values_in_I_s[i].second, BWD))
                    return true;

                input_for_step_1.push_back(
                                           std::pair<bwt_interval, word_t>(bwt_interval(c, L_P.get_C(values_in_I_s[i].first+1)-1),
                                           values_in_I_s[i].second)
                                          );
            }

            return false; 
        }


        bool rpq_interval_check(RpqAutomata &A,
                                std::vector<word_t>& B_array,
                                std::pair<uint64_t,uint64_t> current_interval,
                                high_resolution_clock::time_point start
                               )
        {

            high_resolution_clock::time_point stop;
            //start = high_resolution_clock::now();
            double total_time = 0.0;
            duration<double> time_span;
            
            initializable_array<word_t> D_array(4*(max_O+1), 0);

            std::vector<std::pair<bwt_interval, word_t>> input_for_step_1;
            std::vector<std::pair<bwt_interval, word_t>> input_for_step_2;

            word_t current_D = (word_t)A.getFinalStates(); // palabra de maquina D, con los estados activos
 
            input_for_step_1.push_back(std::pair<bwt_interval, word_t>(
                                       bwt_interval(
				                    L_P.get_C(current_interval.first),
						    L_P.get_C(current_interval.second+1)-1
				                   ), 
                                       current_D)
                                      );

            bool time_out = false;

            while (input_for_step_1.size() > 0) {
               /* stop = high_resolution_clock::now();
                time_span = duration_cast<microseconds>(stop - start);
                total_time = time_span.count();
                if (total_time > TIME_OUT) break;  // 10 minute timeout     
                */
                // STEP 1
                input_for_step_2.clear();
                for (uint64_t i = 0; !time_out and i < input_for_step_1.size(); i++) {
                    stop = high_resolution_clock::now();
                    time_span = duration_cast<microseconds>(stop - start);
                    total_time = time_span.count();
                    if (total_time > TIME_OUT) time_out = true;  // 10 minute timeout     

                    current_D = input_for_step_1[i].second;
                    step_1(A, B_array, current_D, input_for_step_1[i].first, input_for_step_2);
                }

                if (time_out) break;

                // STEP 2 (includes step 3 from the paper)
                input_for_step_1.clear(); // clears it as they have been processed

                for (uint64_t i = 0; !time_out and i < input_for_step_2.size(); i++) {
                    stop = high_resolution_clock::now();
                    time_span = duration_cast<microseconds>(stop - start);
                    total_time = time_span.count();
                    if (total_time > TIME_OUT) time_out = true;  // 10 minute timeout     

                    current_D = input_for_step_2[i].second;
                    if (step_2_check(A, D_array, current_D, input_for_step_2[i].first, input_for_step_1)) return true;
                }
   
                if (time_out) break;
            }

            return false;
        };


        bool rpq_var_to_var_obtain_o(RpqAutomata& A, 
                                     std::pair<uint64_t,uint64_t> current_interval,
	                             std::vector<uint64_t>& object_vector,
				     std::vector<word_t>& B_array,
				     bool is_right_branch,
				     bool flag,
                                     high_resolution_clock::time_point start
				    )
        {
            //cout << "[" << current_interval.first << "," << current_interval.second << "]" << endl;
            high_resolution_clock::time_point stop;
            double total_time = 0.0;
            duration<double> time_span;
            
            stop = high_resolution_clock::now();
            time_span = duration_cast<microseconds>(stop - start);
            total_time = time_span.count();
            if (total_time > TIME_OUT) return false;  // 10 minute timeout
             
	    if (current_interval.first == current_interval.second) {
	       if ((is_right_branch and flag) or rpq_interval_check(A, B_array, current_interval, start)) {
	           object_vector.push_back(current_interval.first);
	           return false;
	       }
	       else return false;
            }
            else {
                if ((is_right_branch and flag) or rpq_interval_check(A, B_array, current_interval, start)) {
	            uint64_t m = (current_interval.first+current_interval.second)/2;
  		    bool flag1 = rpq_var_to_var_obtain_o(A, std::pair<uint64_t,uint64_t>(current_interval.first, m),
		                                       object_vector, B_array, false, false, start);
		    bool flag2 = rpq_var_to_var_obtain_o(A, std::pair<uint64_t,uint64_t>(m+1,current_interval.second),
		                                         object_vector, B_array, true, flag1, start);
		    return flag1 or flag2;
		}
                else return false;
	    }
	}
        

        void _rpq_const_s_to_var_o(RpqAutomata& A,
                                   std::unordered_map<std::string, uint64_t>& predicates_map,  
                                   std::vector<word_t>& B_array,
                                   uint64_t initial_object,
                                   std::vector<std::pair<uint64_t,uint64_t>>& output_subjects,
				   bool const_to_var,
                                   high_resolution_clock::time_point start
                                  )
        {
            high_resolution_clock::time_point stop;
            //start = high_resolution_clock::now();
            double total_time = 0.0;
            duration<double> time_span;

            word_t current_D;  // palabra de maquina D, con los estados activos
            initializable_array<word_t> D_array(4*(max_O+1), 0);
            // Conjuntos de intervalos para cada paso del algoritmo.
            // Cada intervalo está acompañado del correspondiente conjunto de estados activos del NFA A
            std::vector<std::pair<bwt_interval, word_t>> input_for_step_1;
            std::vector<std::pair<bwt_interval, word_t>> input_for_step_2;

            current_D = (word_t)A.getFinalStates();

            //cout << "   Final states: " << current_D << " Initial Object: " << initial_object << endl;
            //cout << "BWT interval: [" << L_P.get_C(initial_object) << ", " << L_P.get_C(initial_object+1)-1 << "]" << endl; 


            input_for_step_1.push_back(std::pair<bwt_interval, word_t>(
                                       bwt_interval(L_P.get_C(initial_object), L_P.get_C(initial_object+1)-1),
                                       current_D)
                                      );
            //cout << "Initial final states: " << current_D << endl; 

            if (A.atFinal(current_D, BWD)) {
                //cout << "Si, lo está encontrando" << endl;
                output_subjects.push_back(std::pair<uint64_t,uint64_t>(initial_object,initial_object));
            }

            bool time_out = false;

            while (input_for_step_1.size() > 0) {
/*                stop = high_resolution_clock::now();
                time_span = duration_cast<microseconds>(stop - start);
                total_time = time_span.count();
                if (total_time > TIME_OUT) break;  // 10 minute timeout                */
                // STEP 1
                input_for_step_2.clear();
                for (uint64_t i = 0; !time_out and i < input_for_step_1.size(); i++) {
                    stop = high_resolution_clock::now();
                    time_span = duration_cast<microseconds>(stop - start);
                    total_time = time_span.count();
                    if (total_time > TIME_OUT) time_out = true;  // 10 minute timeout   
                    current_D = input_for_step_1[i].second;
                    step_1(A, B_array, current_D, input_for_step_1[i].first, input_for_step_2);
                }

                if (time_out) break;

                // STEP 2 (includes step 3 from the paper)
                input_for_step_1.clear(); // clears it as they have been processed

                for (uint64_t i = 0; !time_out and i < input_for_step_2.size(); i++) {
                    stop = high_resolution_clock::now();
                    time_span = duration_cast<microseconds>(stop - start);
                    total_time = time_span.count();
                    if (total_time > TIME_OUT) time_out = true;  // 10 minute timeout   

                    current_D = input_for_step_2[i].second;
                    step_2(A, D_array, current_D, input_for_step_2[i].first, input_for_step_1, initial_object, output_subjects,const_to_var);
                }

                if (time_out) break;
            }
        };




public:
        void rpq_const_s_to_var_o(const std::string& rpq,
                 unordered_map<std::string, uint64_t>& predicates_map,  // ToDo: esto debería ser una variable miembro de la clase
                 std::vector<word_t>& B_array,
                 uint64_t initial_object,
                 std::vector<std::pair<uint64_t,uint64_t>>& output_subjects)
        {
	    std::string query, str_aux;

            for (int64_t i = rpq.size()-1; i >= 0; i--) {
                if (rpq[i] == '|')
                    query += '|';
                else
                if (rpq[i] == ')')
                    query += '(';
                else
                if (rpq[i] == '(')
                    query += ')';
                else
                if (rpq[i] == '<') {
                    std::reverse(str_aux.begin(), str_aux.end());
                    if (str_aux[0] == '%') {
                        predicates_map["<"+str_aux] = real_max_P + predicates_map["<" + str_aux.substr(1,str_aux.size()-1)];
                        //cout << "Adding predicate " << "<"+str_aux << " with id " << real_max_P + predicates_map["<" + str_aux.substr(1,str_aux.size()-1)] << endl;
                    }
                    query += "<" + str_aux;
                    str_aux.clear();
                }
                else
                    str_aux += rpq[i];
            }

            //cout << "Esta es la query que va a ejecutar: " << query << endl;
            RpqAutomata A(query, predicates_map);
            //cout << "Autómata construido" << endl; fflush(stdout);	

            // ToDo: actualmente asume que el arreglo B_array tiene espacio tambien para las hojas del WT
            // Se puede cambiar y reducir el espacio del arreglo a la mitad, manejando las hojas con 
            // el unordered map
            std::unordered_map<uint64_t, uint64_t> m = A.getB();
            for (std::unordered_map<uint64_t, uint64_t>::iterator it = m.begin(); it != m.end(); it++) {
                L_P.mark<word_t>(it->first, B_array, (word_t)it->second);
            }

            high_resolution_clock::time_point start;
            double total_time = 0.0;
            duration<double> time_span;
            start = high_resolution_clock::now();

            _rpq_const_s_to_var_o(A, predicates_map, B_array, initial_object, output_subjects, true, start);

            for (std::unordered_map<uint64_t, uint64_t>::iterator it = m.begin(); it != m.end(); it++) {
                L_P.unmark<word_t>(it->first, B_array);
            }
	};


        void rpq_var_s_to_const_o(const std::string& rpq,
                 unordered_map<std::string, uint64_t>& predicates_map,  // ToDo: esto debería ser una variable miembro de la clase
                 std::vector<word_t>& B_array,
                 uint64_t initial_object,
                 std::vector<std::pair<uint64_t,uint64_t>>& output_subjects)
        {
            std::string query, str_aux;

            for (int64_t i = 0; i < rpq.size(); i++) {
                if (rpq[i] == '|')
                    query += '|';
                else
                if (rpq[i] == ')')
                    query += ')';
                else
                if (rpq[i] == '(')
                    query += '(';
                else
		if (rpq[i] == '*')
		    query += '*';
		else
                if (rpq[i] == '+')
                    query += '+';
                else
		if (rpq[i] == '?')
		    query += '?';
		else
                if (rpq[i] == '>') {
                    //std::reverse(str_aux.begin(), str_aux.end());
                    //cout << "Leyó " << str_aux << endl;
		    if (str_aux[0] != '%') {
                        str_aux = str_aux + ">";
                        uint64_t temp = predicates_map[str_aux];
                        str_aux = "<%" + str_aux.substr(1, str_aux.size()-1); 
                        predicates_map[str_aux] = real_max_P + temp;
                        //cout << "Adding predicate " << str_aux << " with id " << real_max_P + temp << endl;
                    }
                    else {
		        str_aux = "<" + str_aux.substr(2, str_aux.size()-1) + ">";
		    } 

                    query += str_aux;
                    str_aux.clear();
                }
                else
                    str_aux += rpq[i];
            }

            //cout << "Esta es la query que va a ejecutar: " << query << endl;
            RpqAutomata A(query, predicates_map);
            //cout << "Autómata construido" << endl; fflush(stdout);

            // ToDo: actualmente asume que el arreglo B_array tiene espacio tambien para las hojas del WT
            // Se puede cambiar y reducir el espacio del arreglo a la mitad, manejando las hojas con 
            // el unordered map
            std::unordered_map<uint64_t, uint64_t> m = A.getB();
            for (std::unordered_map<uint64_t, uint64_t>::iterator it = m.begin(); it != m.end(); it++) {
                L_P.mark<word_t>(it->first, B_array, (word_t)it->second);
            }

            high_resolution_clock::time_point start;
            double total_time = 0.0;
            duration<double> time_span;
            start = high_resolution_clock::now();

            _rpq_const_s_to_var_o(A, predicates_map, B_array, initial_object, output_subjects,false, start);

            for (std::unordered_map<uint64_t, uint64_t>::iterator it = m.begin(); it != m.end(); it++) {
                L_P.unmark<word_t>(it->first, B_array);
            }
        };

        void rpq_var_s_to_var_o(const std::string& rpq,
                 unordered_map<std::string, uint64_t>& predicates_map,  // ToDo: esto debería ser una variable miembro de la clase
                 std::vector<word_t>& B_array,
                 std::vector<std::pair<uint64_t,uint64_t>>& output_subjects)
        {
            std::string query, str_aux;
            for (int64_t i = rpq.size()-1; i >= 0; i--) {
                if (rpq[i] == '|')
                    query += '|';
                else
                if (rpq[i] == ')')
                    query += '(';
                else
                if (rpq[i] == '(')
                    query += ')';
                else
                if (rpq[i] == '<') {
                    std::reverse(str_aux.begin(), str_aux.end());
                    if (i > 0 and rpq[i-1] == '%') {
                        predicates_map["<%"+str_aux] = real_max_P + predicates_map["<" + str_aux];
                        i--;
                        query += "<%" + str_aux; 
                    }
                    else
                        query += "<" + str_aux;
                    str_aux.clear();
                }
                else
                    str_aux += rpq[i];
            }

            //cout << "Esta es la query que va a ejecutar: " << query << endl;
            RpqAutomata A(query, predicates_map);
            //cout << "Autómata construido" << endl; fflush(stdout);

            // ToDo: actualmente asume que el arreglo B_array tiene espacio tambien para las hojas del WT
            // Se puede cambiar y reducir el espacio del arreglo a la mitad, manejando las hojas con 
            // el unordered map
            std::unordered_map<uint64_t, uint64_t> m = A.getB();
            for (std::unordered_map<uint64_t, uint64_t>::iterator it = m.begin(); it != m.end(); it++) {
                L_P.mark<word_t>(it->first, B_array, (word_t)it->second);
            }

            std::vector<uint64_t> object_vector;

            high_resolution_clock::time_point start, stop;
            double total_time = 0.0;
            duration<double> time_span;
            start = high_resolution_clock::now();            

            rpq_var_to_var_obtain_o(A, std::pair<uint64_t,uint64_t>(1, max_O), object_vector, B_array, false, false, start);
            //cout << "Ya obtuvo los o y son " << object_vector.size() << endl;            

            for (uint64_t i = 0; i < object_vector.size(); i++) {
                _rpq_const_s_to_var_o(A, predicates_map, B_array, object_vector[i], output_subjects, true, start);
            }

            for (std::unordered_map<uint64_t, uint64_t>::iterator it = m.begin(); it != m.end(); it++) {
                L_P.unmark<word_t>(it->first, B_array);
            }
        };
 };
#endif
