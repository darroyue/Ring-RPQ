g++ -fpermissive -O9 -std=c++11 -DNODEBUG -I ~/include -L ~/lib nfa/src/bitmasks.c nfa/src/options.c nfa/src/parser.c nfa/src/regular.c build-index.cpp -o build-index -lsdsl -ldivsufsort -ldivsufsort64

g++ -fpermissive -O9 -std=c++11 -DNODEBUG -I ~/include -L ~/lib nfa/src/bitmasks.c nfa/src/options.c nfa/src/parser.c nfa/src/regular.c query-index.cpp -o query-index -lsdsl -ldivsufsort -ldivsufsort64

#g++ -fpermissive -O9 -std=c++11 -I ~/include -L ~/lib nfa/src/bitmasks.c nfa/src/options.c nfa/src/parser.c nfa/src/regular.c test-rpq-const-to-var.cpp -o test-rpq-const-to-var -lsdsl -ldivsufsort -ldivsufsort64

#g++ -fpermissive -O9 -std=c++11 -I ~/include -L ~/lib nfa/src/bitmasks.c nfa/src/options.c nfa/src/parser.c nfa/src/regular.c test-rpq-var-to-var.cpp -o test-rpq-var-to-var -lsdsl -ldivsufsort -ldivsufsort64

#g++ -fpermissive -O9 -std=c++11 -I ~/include -L ~/lib nfa/src/bitmasks.c nfa/src/options.c nfa/src/parser.c nfa/src/regular.c test-rpq-var-to-const.cpp -o test-rpq-var-to-const -lsdsl -ldivsufsort -ldivsufsort64

