#include <iostream>
#include "triple_bwt.hpp"
#include <fstream>
#include <sdsl/construct.hpp>
#include <unordered_map>

using namespace std;

using namespace std::chrono;
using timer = std::chrono::high_resolution_clock;


int main(int argc, char **argv)
{

    vector<spo_triple> D, E;

    std::ifstream ifs(argv[1]);
    uint64_t s, p , o;
    //set<spo_triple> S;
    
    D.push_back(spo_triple(1, 3, 4));
    D.push_back(spo_triple(4, 3, 1));
    D.push_back(spo_triple(4, 4, 1));
    D.push_back(spo_triple(1, 2, 3));
    D.push_back(spo_triple(3, 2, 1));
    D.push_back(spo_triple(2, 1, 3));
    D.push_back(spo_triple(3, 1, 2));
    D.push_back(spo_triple(2, 1, 5));
    D.push_back(spo_triple(5, 1, 2));
    D.push_back(spo_triple(4, 3, 5));
    D.push_back(spo_triple(5, 3, 4));
    D.push_back(spo_triple(2, 4, 4));
    D.push_back(spo_triple(1, 4, 2));
    D.push_back(spo_triple(1, 3, 9));
    D.push_back(spo_triple(9, 3, 1));
    D.push_back(spo_triple(5, 3, 6));
    D.push_back(spo_triple(6, 3, 5));
    D.push_back(spo_triple(6, 4, 10));
    D.push_back(spo_triple(3, 1, 7));
    D.push_back(spo_triple(7, 1, 3));
    D.push_back(spo_triple(7, 1, 9));
    D.push_back(spo_triple(9, 1, 7));
    D.push_back(spo_triple(9, 4, 10));
    D.push_back(spo_triple(10, 4, 8));
    
    /*D.push_back(spo_triple(8, 4, 10));
    D.push_back(spo_triple(10,4,9));
    D.push_back(spo_triple(8, 4, 6));
    */

//D.push_back(spo_triple(2, 5, 1));
    //D.push_back(spo_triple(4, 5, 2));
    //D.push_back(spo_triple(1, 5, 4));

   //D.push_back(spo_triple(1, 4, 3));
    //D.push_back(spo_triple(2, 4, 5));
   /* D.push_back(spo_triple(4, 4, 5));
    D.push_back(spo_triple(5, 5, 4));
    D.push_back(spo_triple(1, 4, 4));
    D.push_back(spo_triple(4, 5, 1));   
*/
 
    D.shrink_to_fit();
    cout << "--Indexing " << D.size() << " triples" << endl;
    //memory_monitor::start();
    auto start = timer::now();
    
    ring_rpq A(D);
    auto stop = timer::now();

    std::unordered_map<std::string, uint64_t> predicates;

    predicates["<l1>"] = 1;
    predicates["<l2>"] = 2;
    predicates["<l5>"] = 3;
    predicates["<bus>"] = 4;
    //predicates["<Inv-bus>"] = 5;

    std::vector<word_t> B_array;
    std::vector<std::pair<uint64_t,uint64_t>> output_subjects;

    for (uint64_t i = 0; i < 100; i++)
        B_array.push_back(0);

    //std::vector<string> rpq;
    
    //rpq.push_back("<l5>+");
    //rpq.push_back("<l5>");

    A.rpq_var_s_to_var_o(
           /*"<l5>*<l5><bus><bus>*"*/
           /*"<l5><bus><bus>*"*/
           /*"<l1>*<l1><l2>"*/
           /*"<l1>*<bus>?"*/
           /*"<l1><l1>*(<%bus>|<bus>)"*/
           /*"<l5><bus>*"*/
           /*"<l1><l1>*(<bus>|<l2>)"*/
           "<bus>*"
           /*"<l1><l1>*<l2>"*/
	   /*"(<bus>|(<l1><l2>))<l5>*<l5>"*/, predicates, B_array,  output_subjects);

    cout << output_subjects.size() << " subjects reported: " << endl;
    for (uint64_t i = 0; i < output_subjects.size(); i++)
        cout << "(" << output_subjects[i].first << ", " << output_subjects[i].second << ")" << endl;
 
    //memory_monitor::stop();
    //cout << "  Index built " << A.size() << " bytes" << endl;
     
    //A.save(string(argv[1]));
    //cout << "Index saved" << endl;
    cout << duration_cast<seconds>(stop-start).count() << " seconds." << endl;
    //cout << memory_monitor::peak() << " bytes." << endl;
    return 0;
}

