#include <iostream>
#include "triple_bwt.hpp"
#include <fstream>
#include <sdsl/construct.hpp>

using namespace std;

using namespace std::chrono;
using timer = std::chrono::high_resolution_clock;


int main(int argc, char **argv)
{

    if (argc < 3) {
        cerr << "  Usage: " << argv[0] << " <ring-index-file> <queries-file>" << endl;
	exit(1);
    }

    ring_rpq graph;

    graph.load(string(argv[1]));
  
    cout << "  Index loaded " << endl;

    std::ifstream ifs_SO(string(argv[1])+".SO", std::ifstream::in);
    std::ifstream ifs_P(string(argv[1])+".P", std::ifstream::in);
    std::ifstream ifs_q(argv[2], std::ifstream::in);

    std::unordered_map<string, uint64_t> map_SO;
    std::unordered_map<string, uint64_t> map_P;

    uint64_t id;
    string s_aux;

    do {
        ifs_SO >> id;
        ifs_SO >> s_aux;
        map_SO[s_aux] = id;
    } while (!ifs_SO.eof());

    do {
        ifs_P >> id;
        ifs_P >> s_aux;
        map_P[s_aux] = id;
    } while (!ifs_P.eof());


    std::unordered_map<std::string, uint64_t> pred_map;
    std::string query, line;
    uint64_t s_id, o_id, n_line = 0, q = 0;
    bool flag_s, flag_o, skip_flag;
    std::vector<std::pair<uint64_t,uint64_t>> query_output;
    std::vector<word_t> B_array(4*graph.n_labels(), 0);
  
    high_resolution_clock::time_point start, stop;
    double total_time = 0.0;
    duration<double> time_span;



    //cout << "B_array has " << B_array.size() << " elements" << endl;

    do {
        getline(ifs_q, line);
        //stringstream X(line);
 
        pred_map.clear();
        query.clear();
        query_output.clear();
        flag_s = flag_o = false;
	skip_flag = false;
        n_line++;

        stringstream X(line);
        q++;

        if (line.at(0) == '?') {
            flag_s = false;
            X >> s_aux;
	    if (line.at(line.size()-3) == '?') {
	        flag_o = false;
	        line.pop_back();
		line.pop_back();
		line.pop_back();
	    } else {
	        flag_o = true;
                string s_aux_2;
                uint64_t i = line.size()-1;

                while (line.at(i) != ' ') i--;
                i++;
                while(i < line.size()-1/*line.at(i) != '>'*/)
                    s_aux_2 += line.at(i++);
                
                //s_aux_2 += '>';
                //cout << "s_aux_2 = " << s_aux_2 << endl;
                //cin >> i; 
                if (map_SO.find(s_aux_2) != map_SO.end()) {
                    o_id = map_SO[s_aux_2];
                    i = 0;
                    while (i < s_aux_2.size()+1) {
                        line.pop_back();
                        i++;
                    }
                } else
                    skip_flag = true;

            }
        } else {
	    flag_s = true;
	    X >> s_aux;
            //cout << "s_aux = " << s_aux << endl;
            //int j; 
            //cin >> j;
            if (map_SO.find(s_aux) != map_SO.end()) {
	        s_id = map_SO[s_aux];
	    } else
	        skip_flag = true;

            //cout << "line - 2 = " << line.at(line.size()-2) << endl;
            //cin >> j;
            if (line.at(line.size()-3) == '?') {
                flag_o = false;
                line.pop_back();
                line.pop_back();
                line.pop_back();
            } else {
                flag_o = true;
                string s_aux_2;
                uint64_t i = line.size()-2;
                while (line.at(i) != ' ') i--;
                i++;
                while(i < line.size()-1 /*line.at(i) != '>'*/)
                    s_aux_2 += line.at(i++);
          
                //s_aux_2 += '>';

                //cout << "s_aux_2 2 = " << s_aux_2 << endl;
                //int j;
                //cin >> j;
                if (map_SO.find(s_aux_2) != map_SO.end()) {
                    o_id = map_SO[s_aux_2];
                    i = 0;
                    while (i < s_aux_2.size()+1) {
                        line.pop_back();
                        i++;
                    }
                } else
                    skip_flag = true; 
	    }
        }
        
        
        //line.shrink_to_fit(); 
        //cout << "Query " << q << " >> " << line << endl;
        
        stringstream X_a(line);
        X_a >> s_aux;       
 

        if (!skip_flag) {
            X_a >> s_aux;
            do {
                for (uint64_t i = 0; i < s_aux.size(); i++) {
                    //cout << s_aux[i] << " " << i << endl;
                    if (s_aux.at(i) == '<') {
                        std::string s_aux_2;
                        s_aux_2.clear();

                        while (s_aux.at(i) != '>') {
                            s_aux_2 += s_aux.at(i++);
                        }
                        s_aux_2 += s_aux.at(i);
                        //cout << "Esto es lo que leyo " << s_aux_2 << endl;

                        if (map_P.find(s_aux_2) != map_P.end()) {
                            query += s_aux_2; 
		    	    pred_map[s_aux_2] = map_P[s_aux_2];
                            //cout << "Query is " << query << endl;
                            //cout << "pred_map[" << s_aux_2 << "] = " << map_P[s_aux_2] << endl;
		        } else {
                            cout << q << ";0;0" << endl;// << s_aux_2 << " l" << n_line << ": " << line << endl;
                            skip_flag = true;
                            break;
                        }
                    } else {
                        if (s_aux.at(i) != '/' and s_aux.at(i) != ' ') {
		            if (s_aux.at(i) == '^')
			        query += '%';   // si el archivo de queries tiene esto, hay que cambiar el simbolo
                            else
			        query += s_aux.at(i);
	                }
                    }
                }
            //if (skip_flag) break;

            } while (!skip_flag and X_a >> s_aux);
        
	    if (!skip_flag) {
                start = high_resolution_clock::now(); 
                //cout << "Esta es la query: " << query << endl;
   	        if (!flag_s and !flag_o) {
	            //cout <<  "?s RPQ ?o = ?s " << query << " ?o: "; fflush(stdout);
		    graph.rpq_var_s_to_var_o(query, pred_map, B_array, query_output);
	        } else {
	            if (flag_s) {
		        //cout << "s RPQ ?o = " << s_id << " " << query << " ?o: "; fflush(stdout);  
		        graph.rpq_const_s_to_var_o(query, pred_map, B_array, s_id, query_output);
		    } else {
		        //cout << "?s RPQ o = ?s " << query << " o: "; fflush(stdout); 
		        graph.rpq_var_s_to_const_o(query, pred_map, B_array, o_id, query_output);
		    }
	        }
                stop = high_resolution_clock::now();
                time_span = duration_cast<microseconds>(stop - start);
                total_time = time_span.count();

                cout << q << ";" <<  query_output.size() << ";" << (uint64_t)(total_time*1000000000ULL) << endl;
 

	    } else skip_flag = false;
        }
        else { cout << q << ";0;0" << endl; skip_flag = false;}
    } while(!ifs_q.eof());


    return 0;
}

